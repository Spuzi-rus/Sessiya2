﻿
namespace Mebelnaya_Fabrika
{
    partial class Spisok_Zakazov
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Spisok_Zakazov));
            this.Panel = new System.Windows.Forms.Panel();
            this.Metka_Spisok_Zakazov = new System.Windows.Forms.Label();
            this.Logotip = new System.Windows.Forms.PictureBox();
            this.mebelnaya_FabrikaDataSet = new Mebelnaya_Fabrika.Mebelnaya_FabrikaDataSet();
            this.zakazBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.zakazTableAdapter = new Mebelnaya_Fabrika.Mebelnaya_FabrikaDataSetTableAdapters.ZakazTableAdapter();
            this.tableAdapterManager = new Mebelnaya_Fabrika.Mebelnaya_FabrikaDataSetTableAdapters.TableAdapterManager();
            this.zakazDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sohranit = new System.Windows.Forms.Button();
            this.Nazad = new System.Windows.Forms.Button();
            this.Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logotip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mebelnaya_FabrikaDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakazBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakazDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel
            // 
            this.Panel.BackColor = System.Drawing.SystemColors.GrayText;
            this.Panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel.Controls.Add(this.Metka_Spisok_Zakazov);
            this.Panel.Controls.Add(this.Logotip);
            this.Panel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Panel.ForeColor = System.Drawing.SystemColors.Control;
            this.Panel.Location = new System.Drawing.Point(12, 12);
            this.Panel.Name = "Panel";
            this.Panel.Size = new System.Drawing.Size(730, 102);
            this.Panel.TabIndex = 14;
            // 
            // Metka_Spisok_Zakazov
            // 
            this.Metka_Spisok_Zakazov.AutoSize = true;
            this.Metka_Spisok_Zakazov.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Metka_Spisok_Zakazov.Location = new System.Drawing.Point(282, 38);
            this.Metka_Spisok_Zakazov.Name = "Metka_Spisok_Zakazov";
            this.Metka_Spisok_Zakazov.Size = new System.Drawing.Size(165, 24);
            this.Metka_Spisok_Zakazov.TabIndex = 1;
            this.Metka_Spisok_Zakazov.Text = "Список заказов";
            // 
            // Logotip
            // 
            this.Logotip.Image = ((System.Drawing.Image)(resources.GetObject("Logotip.Image")));
            this.Logotip.Location = new System.Drawing.Point(3, 3);
            this.Logotip.Name = "Logotip";
            this.Logotip.Size = new System.Drawing.Size(97, 94);
            this.Logotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Logotip.TabIndex = 0;
            this.Logotip.TabStop = false;
            // 
            // mebelnaya_FabrikaDataSet
            // 
            this.mebelnaya_FabrikaDataSet.DataSetName = "Mebelnaya_FabrikaDataSet";
            this.mebelnaya_FabrikaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // zakazBindingSource
            // 
            this.zakazBindingSource.DataMember = "Zakaz";
            this.zakazBindingSource.DataSource = this.mebelnaya_FabrikaDataSet;
            // 
            // zakazTableAdapter
            // 
            this.zakazTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.FurnituraTableAdapter = null;
            this.tableAdapterManager.MaterialyTableAdapter = null;
            this.tableAdapterManager.OborudovanieTableAdapter = null;
            this.tableAdapterManager.PolzovateliTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Mebelnaya_Fabrika.Mebelnaya_FabrikaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.ZakazTableAdapter = this.zakazTableAdapter;
            // 
            // zakazDataGridView
            // 
            this.zakazDataGridView.AutoGenerateColumns = false;
            this.zakazDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.zakazDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.zakazDataGridView.DataSource = this.zakazBindingSource;
            this.zakazDataGridView.Location = new System.Drawing.Point(12, 120);
            this.zakazDataGridView.Name = "zakazDataGridView";
            this.zakazDataGridView.Size = new System.Drawing.Size(730, 220);
            this.zakazDataGridView.TabIndex = 15;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Номер";
            this.dataGridViewTextBoxColumn1.HeaderText = "Номер";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Дата";
            this.dataGridViewTextBoxColumn2.HeaderText = "Дата";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Наименование_заказа";
            this.dataGridViewTextBoxColumn3.HeaderText = "Наименование_заказа";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Заказчик";
            this.dataGridViewTextBoxColumn5.HeaderText = "Заказчик";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Ответственный_менеджер";
            this.dataGridViewTextBoxColumn6.HeaderText = "Ответственный_менеджер";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Стоимость";
            this.dataGridViewTextBoxColumn7.HeaderText = "Стоимость";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Плановая_дата_завершения";
            this.dataGridViewTextBoxColumn8.HeaderText = "Плановая_дата_завершения";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // Sohranit
            // 
            this.Sohranit.Location = new System.Drawing.Point(649, 346);
            this.Sohranit.Name = "Sohranit";
            this.Sohranit.Size = new System.Drawing.Size(93, 39);
            this.Sohranit.TabIndex = 18;
            this.Sohranit.Text = "Сохранить";
            this.Sohranit.UseVisualStyleBackColor = true;
            this.Sohranit.Click += new System.EventHandler(this.Sohranit_Click);
            // 
            // Nazad
            // 
            this.Nazad.Location = new System.Drawing.Point(12, 412);
            this.Nazad.Name = "Nazad";
            this.Nazad.Size = new System.Drawing.Size(93, 39);
            this.Nazad.TabIndex = 19;
            this.Nazad.Text = "Назад";
            this.Nazad.UseVisualStyleBackColor = true;
            this.Nazad.Click += new System.EventHandler(this.Nazad_Click);
            // 
            // Spisok_Zakazov
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(754, 463);
            this.Controls.Add(this.Nazad);
            this.Controls.Add(this.Sohranit);
            this.Controls.Add(this.zakazDataGridView);
            this.Controls.Add(this.Panel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Spisok_Zakazov";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Список заказов";
            this.Load += new System.EventHandler(this.Spisok_Zakazov_Load);
            this.Panel.ResumeLayout(false);
            this.Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logotip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mebelnaya_FabrikaDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakazBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zakazDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Panel;
        private System.Windows.Forms.Label Metka_Spisok_Zakazov;
        private System.Windows.Forms.PictureBox Logotip;
        private Mebelnaya_FabrikaDataSet mebelnaya_FabrikaDataSet;
        private System.Windows.Forms.BindingSource zakazBindingSource;
        private Mebelnaya_FabrikaDataSetTableAdapters.ZakazTableAdapter zakazTableAdapter;
        private Mebelnaya_FabrikaDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView zakazDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.Button Sohranit;
        private System.Windows.Forms.Button Nazad;
    }
}