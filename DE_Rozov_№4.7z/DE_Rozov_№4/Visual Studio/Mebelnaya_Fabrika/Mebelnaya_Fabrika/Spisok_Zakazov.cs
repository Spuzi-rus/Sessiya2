﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mebelnaya_Fabrika
{
    public partial class Spisok_Zakazov : Form
    {
        public Spisok_Zakazov()
        {
            InitializeComponent();
        }

        private void zakazBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.zakazBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.mebelnaya_FabrikaDataSet);

        }

        private void Spisok_Zakazov_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "mebelnaya_FabrikaDataSet.Zakaz". При необходимости она может быть перемещена или удалена.
            this.zakazTableAdapter.Fill(this.mebelnaya_FabrikaDataSet.Zakaz);

        }

        private void Sohranit_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.zakazBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.mebelnaya_FabrikaDataSet);
        }

        private void Nazad_Click(object sender, EventArgs e)
        {
            Polzovatel_Zakazchik pz = new Polzovatel_Zakazchik();
            pz.Show();
            this.Hide();
        }
    }
}
