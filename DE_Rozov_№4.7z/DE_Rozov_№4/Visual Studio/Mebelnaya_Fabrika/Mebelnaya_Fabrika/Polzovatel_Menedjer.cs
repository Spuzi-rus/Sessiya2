﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mebelnaya_Fabrika
{
    public partial class Polzovatel_Menedjer : Form
    {
        public Polzovatel_Menedjer()
        {
            InitializeComponent();
        }

        private void Uchet_Materialov_Click(object sender, EventArgs e)
        {
            Uchet_Materialov_Master_Menedjer uchet = new Uchet_Materialov_Master_Menedjer();
            uchet.Show();
            this.Hide();
        }

        private void Uchet_Furnitury_Click(object sender, EventArgs e)
        {
            Uchet_Furnitury_Master_Menedjer uchet = new Uchet_Furnitury_Master_Menedjer();
            uchet.Show();
            this.Hide();
        }

        private void Nazad_Click(object sender, EventArgs e)
        {
            Avtorizatsiya avt = new Avtorizatsiya();
            avt.Show();
            this.Hide();
        }
    }
}
