﻿namespace Mebelnaya_Fabrika
{
    partial class Menyu
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menyu));
            this.Menyu_Avtorizatsiya = new System.Windows.Forms.Button();
            this.Menyu_Registratsiya = new System.Windows.Forms.Button();
            this.Panel = new System.Windows.Forms.Panel();
            this.Metka_Mebelnaya_Fabrika = new System.Windows.Forms.Label();
            this.Logotip = new System.Windows.Forms.PictureBox();
            this.Vyhod = new System.Windows.Forms.Button();
            this.Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logotip)).BeginInit();
            this.SuspendLayout();
            // 
            // Menyu_Avtorizatsiya
            // 
            this.Menyu_Avtorizatsiya.Location = new System.Drawing.Point(232, 205);
            this.Menyu_Avtorizatsiya.Name = "Menyu_Avtorizatsiya";
            this.Menyu_Avtorizatsiya.Size = new System.Drawing.Size(108, 52);
            this.Menyu_Avtorizatsiya.TabIndex = 2;
            this.Menyu_Avtorizatsiya.Text = "Авторизация";
            this.Menyu_Avtorizatsiya.UseVisualStyleBackColor = true;
            this.Menyu_Avtorizatsiya.Click += new System.EventHandler(this.Menyu_Dalee_Click);
            // 
            // Menyu_Registratsiya
            // 
            this.Menyu_Registratsiya.Location = new System.Drawing.Point(418, 205);
            this.Menyu_Registratsiya.Name = "Menyu_Registratsiya";
            this.Menyu_Registratsiya.Size = new System.Drawing.Size(104, 52);
            this.Menyu_Registratsiya.TabIndex = 23;
            this.Menyu_Registratsiya.Text = "Регистрация";
            this.Menyu_Registratsiya.UseVisualStyleBackColor = true;
            this.Menyu_Registratsiya.Click += new System.EventHandler(this.Menyu_Registratsiya_Click);
            // 
            // Panel
            // 
            this.Panel.BackColor = System.Drawing.SystemColors.GrayText;
            this.Panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel.Controls.Add(this.Metka_Mebelnaya_Fabrika);
            this.Panel.Controls.Add(this.Logotip);
            this.Panel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Panel.ForeColor = System.Drawing.SystemColors.Control;
            this.Panel.Location = new System.Drawing.Point(12, 12);
            this.Panel.Name = "Panel";
            this.Panel.Size = new System.Drawing.Size(730, 102);
            this.Panel.TabIndex = 24;
            // 
            // Metka_Mebelnaya_Fabrika
            // 
            this.Metka_Mebelnaya_Fabrika.AutoSize = true;
            this.Metka_Mebelnaya_Fabrika.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Metka_Mebelnaya_Fabrika.Location = new System.Drawing.Point(260, 38);
            this.Metka_Mebelnaya_Fabrika.Name = "Metka_Mebelnaya_Fabrika";
            this.Metka_Mebelnaya_Fabrika.Size = new System.Drawing.Size(209, 24);
            this.Metka_Mebelnaya_Fabrika.TabIndex = 1;
            this.Metka_Mebelnaya_Fabrika.Text = "Мебельная фабрика";
            // 
            // Logotip
            // 
            this.Logotip.Image = ((System.Drawing.Image)(resources.GetObject("Logotip.Image")));
            this.Logotip.Location = new System.Drawing.Point(3, 3);
            this.Logotip.Name = "Logotip";
            this.Logotip.Size = new System.Drawing.Size(97, 94);
            this.Logotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Logotip.TabIndex = 0;
            this.Logotip.TabStop = false;
            // 
            // Vyhod
            // 
            this.Vyhod.Location = new System.Drawing.Point(12, 412);
            this.Vyhod.Name = "Vyhod";
            this.Vyhod.Size = new System.Drawing.Size(93, 39);
            this.Vyhod.TabIndex = 25;
            this.Vyhod.Text = "Выход";
            this.Vyhod.UseVisualStyleBackColor = true;
            this.Vyhod.Click += new System.EventHandler(this.Vyhod_Click);
            // 
            // Menyu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(754, 463);
            this.Controls.Add(this.Vyhod);
            this.Controls.Add(this.Panel);
            this.Controls.Add(this.Menyu_Registratsiya);
            this.Controls.Add(this.Menyu_Avtorizatsiya);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Menyu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Меню";
            this.Panel.ResumeLayout(false);
            this.Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logotip)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button Menyu_Avtorizatsiya;
        private System.Windows.Forms.Button Menyu_Registratsiya;
        private System.Windows.Forms.Panel Panel;
        private System.Windows.Forms.Label Metka_Mebelnaya_Fabrika;
        private System.Windows.Forms.PictureBox Logotip;
        private System.Windows.Forms.Button Vyhod;
    }
}

