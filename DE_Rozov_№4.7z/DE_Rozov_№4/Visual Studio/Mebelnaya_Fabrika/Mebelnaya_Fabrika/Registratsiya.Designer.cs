﻿
namespace Mebelnaya_Fabrika
{
    partial class Registratsiya
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registratsiya));
            this.Panel = new System.Windows.Forms.Panel();
            this.Metka_Registratsiya = new System.Windows.Forms.Label();
            this.Logotip = new System.Windows.Forms.PictureBox();
            this.Metka_Imya = new System.Windows.Forms.Label();
            this.Metka_Familiya = new System.Windows.Forms.Label();
            this.Metka_Otchestvo = new System.Windows.Forms.Label();
            this.Metka_Login = new System.Windows.Forms.Label();
            this.Metka_Parol = new System.Windows.Forms.Label();
            this.tbImya = new System.Windows.Forms.TextBox();
            this.tbFamiliya = new System.Windows.Forms.TextBox();
            this.tbOtchestvo = new System.Windows.Forms.TextBox();
            this.tbLogin = new System.Windows.Forms.TextBox();
            this.tbParol = new System.Windows.Forms.TextBox();
            this.Registratsiya_Registratsiya = new System.Windows.Forms.Button();
            this.Metka_Vvod_Dannyh = new System.Windows.Forms.Label();
            this.Ssylka_Avtorizatsiya = new System.Windows.Forms.LinkLabel();
            this.Metka_Rol = new System.Windows.Forms.Label();
            this.tbRol = new System.Windows.Forms.TextBox();
            this.Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logotip)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel
            // 
            this.Panel.BackColor = System.Drawing.SystemColors.GrayText;
            this.Panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel.Controls.Add(this.Metka_Registratsiya);
            this.Panel.Controls.Add(this.Logotip);
            this.Panel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Panel.ForeColor = System.Drawing.SystemColors.Control;
            this.Panel.Location = new System.Drawing.Point(12, 12);
            this.Panel.Name = "Panel";
            this.Panel.Size = new System.Drawing.Size(730, 102);
            this.Panel.TabIndex = 11;
            // 
            // Metka_Registratsiya
            // 
            this.Metka_Registratsiya.AutoSize = true;
            this.Metka_Registratsiya.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Metka_Registratsiya.Location = new System.Drawing.Point(296, 38);
            this.Metka_Registratsiya.Name = "Metka_Registratsiya";
            this.Metka_Registratsiya.Size = new System.Drawing.Size(137, 24);
            this.Metka_Registratsiya.TabIndex = 1;
            this.Metka_Registratsiya.Text = "Регистрация";
            // 
            // Logotip
            // 
            this.Logotip.Image = ((System.Drawing.Image)(resources.GetObject("Logotip.Image")));
            this.Logotip.Location = new System.Drawing.Point(3, 3);
            this.Logotip.Name = "Logotip";
            this.Logotip.Size = new System.Drawing.Size(97, 94);
            this.Logotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Logotip.TabIndex = 0;
            this.Logotip.TabStop = false;
            // 
            // Metka_Imya
            // 
            this.Metka_Imya.AutoSize = true;
            this.Metka_Imya.Location = new System.Drawing.Point(265, 204);
            this.Metka_Imya.Name = "Metka_Imya";
            this.Metka_Imya.Size = new System.Drawing.Size(42, 18);
            this.Metka_Imya.TabIndex = 12;
            this.Metka_Imya.Text = "Имя:";
            // 
            // Metka_Familiya
            // 
            this.Metka_Familiya.AutoSize = true;
            this.Metka_Familiya.Location = new System.Drawing.Point(230, 163);
            this.Metka_Familiya.Name = "Metka_Familiya";
            this.Metka_Familiya.Size = new System.Drawing.Size(77, 18);
            this.Metka_Familiya.TabIndex = 13;
            this.Metka_Familiya.Text = "Фамилия:";
            // 
            // Metka_Otchestvo
            // 
            this.Metka_Otchestvo.AutoSize = true;
            this.Metka_Otchestvo.Location = new System.Drawing.Point(228, 244);
            this.Metka_Otchestvo.Name = "Metka_Otchestvo";
            this.Metka_Otchestvo.Size = new System.Drawing.Size(79, 18);
            this.Metka_Otchestvo.TabIndex = 14;
            this.Metka_Otchestvo.Text = "Отчество:";
            // 
            // Metka_Login
            // 
            this.Metka_Login.AutoSize = true;
            this.Metka_Login.Location = new System.Drawing.Point(253, 279);
            this.Metka_Login.Name = "Metka_Login";
            this.Metka_Login.Size = new System.Drawing.Size(54, 18);
            this.Metka_Login.TabIndex = 15;
            this.Metka_Login.Text = "Логин:";
            // 
            // Metka_Parol
            // 
            this.Metka_Parol.AutoSize = true;
            this.Metka_Parol.Location = new System.Drawing.Point(242, 318);
            this.Metka_Parol.Name = "Metka_Parol";
            this.Metka_Parol.Size = new System.Drawing.Size(65, 18);
            this.Metka_Parol.TabIndex = 16;
            this.Metka_Parol.Text = "Пароль:";
            // 
            // tbImya
            // 
            this.tbImya.Location = new System.Drawing.Point(313, 201);
            this.tbImya.Name = "tbImya";
            this.tbImya.Size = new System.Drawing.Size(214, 24);
            this.tbImya.TabIndex = 17;
            // 
            // tbFamiliya
            // 
            this.tbFamiliya.Location = new System.Drawing.Point(313, 160);
            this.tbFamiliya.Name = "tbFamiliya";
            this.tbFamiliya.Size = new System.Drawing.Size(214, 24);
            this.tbFamiliya.TabIndex = 18;
            // 
            // tbOtchestvo
            // 
            this.tbOtchestvo.Location = new System.Drawing.Point(313, 241);
            this.tbOtchestvo.Name = "tbOtchestvo";
            this.tbOtchestvo.Size = new System.Drawing.Size(214, 24);
            this.tbOtchestvo.TabIndex = 19;
            // 
            // tbLogin
            // 
            this.tbLogin.Location = new System.Drawing.Point(313, 276);
            this.tbLogin.Name = "tbLogin";
            this.tbLogin.Size = new System.Drawing.Size(214, 24);
            this.tbLogin.TabIndex = 20;
            // 
            // tbParol
            // 
            this.tbParol.Location = new System.Drawing.Point(313, 315);
            this.tbParol.Name = "tbParol";
            this.tbParol.PasswordChar = '*';
            this.tbParol.Size = new System.Drawing.Size(214, 24);
            this.tbParol.TabIndex = 21;
            // 
            // Registratsiya_Registratsiya
            // 
            this.Registratsiya_Registratsiya.Location = new System.Drawing.Point(325, 388);
            this.Registratsiya_Registratsiya.Name = "Registratsiya_Registratsiya";
            this.Registratsiya_Registratsiya.Size = new System.Drawing.Size(104, 52);
            this.Registratsiya_Registratsiya.TabIndex = 22;
            this.Registratsiya_Registratsiya.Text = "Регистрация";
            this.Registratsiya_Registratsiya.UseVisualStyleBackColor = true;
            this.Registratsiya_Registratsiya.Click += new System.EventHandler(this.Registratsiya_Registratsiya_Click);
            // 
            // Metka_Vvod_Dannyh
            // 
            this.Metka_Vvod_Dannyh.AutoSize = true;
            this.Metka_Vvod_Dannyh.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Metka_Vvod_Dannyh.Location = new System.Drawing.Point(305, 123);
            this.Metka_Vvod_Dannyh.Name = "Metka_Vvod_Dannyh";
            this.Metka_Vvod_Dannyh.Size = new System.Drawing.Size(178, 18);
            this.Metka_Vvod_Dannyh.TabIndex = 23;
            this.Metka_Vvod_Dannyh.Text = "Введите свои данные";
            // 
            // Ssylka_Avtorizatsiya
            // 
            this.Ssylka_Avtorizatsiya.AutoSize = true;
            this.Ssylka_Avtorizatsiya.LinkColor = System.Drawing.Color.Gray;
            this.Ssylka_Avtorizatsiya.Location = new System.Drawing.Point(614, 436);
            this.Ssylka_Avtorizatsiya.Name = "Ssylka_Avtorizatsiya";
            this.Ssylka_Avtorizatsiya.Size = new System.Drawing.Size(128, 18);
            this.Ssylka_Avtorizatsiya.TabIndex = 24;
            this.Ssylka_Avtorizatsiya.TabStop = true;
            this.Ssylka_Avtorizatsiya.Text = "Аккаунт уже есть";
            this.Ssylka_Avtorizatsiya.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Ssylka_Avtorizatsiya_LinkClicked);
            // 
            // Metka_Rol
            // 
            this.Metka_Rol.AutoSize = true;
            this.Metka_Rol.Location = new System.Drawing.Point(259, 352);
            this.Metka_Rol.Name = "Metka_Rol";
            this.Metka_Rol.Size = new System.Drawing.Size(48, 18);
            this.Metka_Rol.TabIndex = 25;
            this.Metka_Rol.Text = "Роль:";
            // 
            // tbRol
            // 
            this.tbRol.Enabled = false;
            this.tbRol.Location = new System.Drawing.Point(313, 349);
            this.tbRol.Name = "tbRol";
            this.tbRol.Size = new System.Drawing.Size(214, 24);
            this.tbRol.TabIndex = 26;
            this.tbRol.Text = "Заказчик";
            // 
            // Registratsiya
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(754, 463);
            this.Controls.Add(this.tbRol);
            this.Controls.Add(this.Metka_Rol);
            this.Controls.Add(this.Ssylka_Avtorizatsiya);
            this.Controls.Add(this.Metka_Vvod_Dannyh);
            this.Controls.Add(this.Registratsiya_Registratsiya);
            this.Controls.Add(this.tbParol);
            this.Controls.Add(this.tbLogin);
            this.Controls.Add(this.tbOtchestvo);
            this.Controls.Add(this.tbFamiliya);
            this.Controls.Add(this.tbImya);
            this.Controls.Add(this.Metka_Parol);
            this.Controls.Add(this.Metka_Login);
            this.Controls.Add(this.Metka_Otchestvo);
            this.Controls.Add(this.Metka_Familiya);
            this.Controls.Add(this.Metka_Imya);
            this.Controls.Add(this.Panel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Registratsiya";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Регистрация";
            this.Panel.ResumeLayout(false);
            this.Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logotip)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel Panel;
        private System.Windows.Forms.Label Metka_Registratsiya;
        private System.Windows.Forms.PictureBox Logotip;
        private System.Windows.Forms.Label Metka_Imya;
        private System.Windows.Forms.Label Metka_Familiya;
        private System.Windows.Forms.Label Metka_Otchestvo;
        private System.Windows.Forms.Label Metka_Login;
        private System.Windows.Forms.Label Metka_Parol;
        private System.Windows.Forms.TextBox tbImya;
        private System.Windows.Forms.TextBox tbFamiliya;
        private System.Windows.Forms.TextBox tbOtchestvo;
        private System.Windows.Forms.TextBox tbLogin;
        private System.Windows.Forms.TextBox tbParol;
        private System.Windows.Forms.Button Registratsiya_Registratsiya;
        private System.Windows.Forms.Label Metka_Vvod_Dannyh;
        private System.Windows.Forms.LinkLabel Ssylka_Avtorizatsiya;
        private System.Windows.Forms.Label Metka_Rol;
        private System.Windows.Forms.TextBox tbRol;
    }
}