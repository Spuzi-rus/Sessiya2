﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mebelnaya_Fabrika
{
    public partial class Polzovatel_Direktor : Form
    {
        public Polzovatel_Direktor()
        {
            InitializeComponent();
        }

        private void oborudovanieBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.oborudovanieBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.mebelnaya_FabrikaDataSet);

        }

        private void Polzovatel_Direktor_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "mebelnaya_FabrikaDataSet.Oborudovanie". При необходимости она может быть перемещена или удалена.
            this.oborudovanieTableAdapter.Fill(this.mebelnaya_FabrikaDataSet.Oborudovanie);

        }

        private void Uchet_Oborudovaniya_Click(object sender, EventArgs e)
        {
            Uchet_Oborudovaniya ub = new Uchet_Oborudovaniya();
            ub.Show();
            this.Hide();
        }

        private void Nazad_Click(object sender, EventArgs e)
        {
            Avtorizatsiya avtor = new Avtorizatsiya();
            avtor.Show();
            this.Hide();
        }

        private void Uchet_Materialov_Click(object sender, EventArgs e)
        {
            Uchet_Materialov uchetm = new Uchet_Materialov();
            uchetm.Show();
            this.Hide();
        }

        private void Uchet_Furnitury_Click(object sender, EventArgs e)
        {
            Uchet_Furnitury uctfur = new Uchet_Furnitury();
            uctfur.Show();
            this.Hide();
        }
    }
}
