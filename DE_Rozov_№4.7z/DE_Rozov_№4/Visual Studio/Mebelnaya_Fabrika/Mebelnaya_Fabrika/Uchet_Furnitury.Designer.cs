﻿
namespace Mebelnaya_Fabrika
{
    partial class Uchet_Furnitury
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Uchet_Furnitury));
            this.Panel = new System.Windows.Forms.Panel();
            this.Metka_Uchet_Furnitury = new System.Windows.Forms.Label();
            this.Logotip = new System.Windows.Forms.PictureBox();
            this.mebelnaya_FabrikaDataSet = new Mebelnaya_Fabrika.Mebelnaya_FabrikaDataSet();
            this.furnituraBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.furnituraTableAdapter = new Mebelnaya_Fabrika.Mebelnaya_FabrikaDataSetTableAdapters.FurnituraTableAdapter();
            this.tableAdapterManager = new Mebelnaya_Fabrika.Mebelnaya_FabrikaDataSetTableAdapters.TableAdapterManager();
            this.furnituraDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nazad = new System.Windows.Forms.Button();
            this.Otmena = new System.Windows.Forms.Button();
            this.Metka_Tip = new System.Windows.Forms.Label();
            this.Nayti = new System.Windows.Forms.Button();
            this.tbPoisk = new System.Windows.Forms.TextBox();
            this.Sohranit = new System.Windows.Forms.Button();
            this.Udalit = new System.Windows.Forms.Button();
            this.Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logotip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mebelnaya_FabrikaDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.furnituraBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.furnituraDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // Panel
            // 
            this.Panel.BackColor = System.Drawing.SystemColors.GrayText;
            this.Panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Panel.Controls.Add(this.Metka_Uchet_Furnitury);
            this.Panel.Controls.Add(this.Logotip);
            this.Panel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Panel.ForeColor = System.Drawing.SystemColors.Control;
            this.Panel.Location = new System.Drawing.Point(12, 12);
            this.Panel.Name = "Panel";
            this.Panel.Size = new System.Drawing.Size(884, 102);
            this.Panel.TabIndex = 14;
            // 
            // Metka_Uchet_Furnitury
            // 
            this.Metka_Uchet_Furnitury.AutoSize = true;
            this.Metka_Uchet_Furnitury.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Metka_Uchet_Furnitury.Location = new System.Drawing.Point(356, 38);
            this.Metka_Uchet_Furnitury.Name = "Metka_Uchet_Furnitury";
            this.Metka_Uchet_Furnitury.Size = new System.Drawing.Size(171, 24);
            this.Metka_Uchet_Furnitury.TabIndex = 1;
            this.Metka_Uchet_Furnitury.Text = "Учёт фурнитуры";
            // 
            // Logotip
            // 
            this.Logotip.Image = ((System.Drawing.Image)(resources.GetObject("Logotip.Image")));
            this.Logotip.Location = new System.Drawing.Point(3, 3);
            this.Logotip.Name = "Logotip";
            this.Logotip.Size = new System.Drawing.Size(97, 94);
            this.Logotip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Logotip.TabIndex = 0;
            this.Logotip.TabStop = false;
            // 
            // mebelnaya_FabrikaDataSet
            // 
            this.mebelnaya_FabrikaDataSet.DataSetName = "Mebelnaya_FabrikaDataSet";
            this.mebelnaya_FabrikaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // furnituraBindingSource
            // 
            this.furnituraBindingSource.DataMember = "Furnitura";
            this.furnituraBindingSource.DataSource = this.mebelnaya_FabrikaDataSet;
            // 
            // furnituraTableAdapter
            // 
            this.furnituraTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.FurnituraTableAdapter = this.furnituraTableAdapter;
            this.tableAdapterManager.MaterialyTableAdapter = null;
            this.tableAdapterManager.OborudovanieTableAdapter = null;
            this.tableAdapterManager.PolzovateliTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Mebelnaya_Fabrika.Mebelnaya_FabrikaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // furnituraDataGridView
            // 
            this.furnituraDataGridView.AutoGenerateColumns = false;
            this.furnituraDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.furnituraDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.furnituraDataGridView.DataSource = this.furnituraBindingSource;
            this.furnituraDataGridView.Location = new System.Drawing.Point(12, 120);
            this.furnituraDataGridView.Name = "furnituraDataGridView";
            this.furnituraDataGridView.Size = new System.Drawing.Size(884, 220);
            this.furnituraDataGridView.TabIndex = 15;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Артикул";
            this.dataGridViewTextBoxColumn1.HeaderText = "Артикул";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Наименование";
            this.dataGridViewTextBoxColumn2.HeaderText = "Наименование";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Количество";
            this.dataGridViewTextBoxColumn3.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Единица измерения";
            this.dataGridViewTextBoxColumn4.HeaderText = "Единица измерения";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Тип";
            this.dataGridViewTextBoxColumn5.HeaderText = "Тип";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Цена";
            this.dataGridViewTextBoxColumn6.HeaderText = "Цена";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // Nazad
            // 
            this.Nazad.Location = new System.Drawing.Point(12, 440);
            this.Nazad.Name = "Nazad";
            this.Nazad.Size = new System.Drawing.Size(93, 39);
            this.Nazad.TabIndex = 31;
            this.Nazad.Text = "Назад";
            this.Nazad.UseVisualStyleBackColor = true;
            this.Nazad.Click += new System.EventHandler(this.Nazad_Click);
            // 
            // Otmena
            // 
            this.Otmena.Location = new System.Drawing.Point(378, 346);
            this.Otmena.Name = "Otmena";
            this.Otmena.Size = new System.Drawing.Size(93, 39);
            this.Otmena.TabIndex = 30;
            this.Otmena.Text = "Отмена";
            this.Otmena.UseVisualStyleBackColor = true;
            this.Otmena.Click += new System.EventHandler(this.Otmena_Click);
            // 
            // Metka_Tip
            // 
            this.Metka_Tip.AutoSize = true;
            this.Metka_Tip.Location = new System.Drawing.Point(19, 356);
            this.Metka_Tip.Name = "Metka_Tip";
            this.Metka_Tip.Size = new System.Drawing.Size(37, 18);
            this.Metka_Tip.TabIndex = 29;
            this.Metka_Tip.Text = "Тип:";
            // 
            // Nayti
            // 
            this.Nayti.Location = new System.Drawing.Point(279, 346);
            this.Nayti.Name = "Nayti";
            this.Nayti.Size = new System.Drawing.Size(93, 39);
            this.Nayti.TabIndex = 28;
            this.Nayti.Text = "Найти";
            this.Nayti.UseVisualStyleBackColor = true;
            this.Nayti.Click += new System.EventHandler(this.Nayti_Click);
            // 
            // tbPoisk
            // 
            this.tbPoisk.Location = new System.Drawing.Point(62, 353);
            this.tbPoisk.Name = "tbPoisk";
            this.tbPoisk.Size = new System.Drawing.Size(211, 24);
            this.tbPoisk.TabIndex = 27;
            // 
            // Sohranit
            // 
            this.Sohranit.Location = new System.Drawing.Point(704, 346);
            this.Sohranit.Name = "Sohranit";
            this.Sohranit.Size = new System.Drawing.Size(93, 39);
            this.Sohranit.TabIndex = 26;
            this.Sohranit.Text = "Сохранить";
            this.Sohranit.UseVisualStyleBackColor = true;
            this.Sohranit.Click += new System.EventHandler(this.Sohranit_Click);
            // 
            // Udalit
            // 
            this.Udalit.Location = new System.Drawing.Point(803, 346);
            this.Udalit.Name = "Udalit";
            this.Udalit.Size = new System.Drawing.Size(93, 39);
            this.Udalit.TabIndex = 25;
            this.Udalit.Text = "Удалить";
            this.Udalit.UseVisualStyleBackColor = true;
            this.Udalit.Click += new System.EventHandler(this.Udalit_Click);
            // 
            // Uchet_Furnitury
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(916, 491);
            this.Controls.Add(this.Nazad);
            this.Controls.Add(this.Otmena);
            this.Controls.Add(this.Metka_Tip);
            this.Controls.Add(this.Nayti);
            this.Controls.Add(this.tbPoisk);
            this.Controls.Add(this.Sohranit);
            this.Controls.Add(this.Udalit);
            this.Controls.Add(this.furnituraDataGridView);
            this.Controls.Add(this.Panel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Uchet_Furnitury";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Учёт фурнитуры";
            this.Load += new System.EventHandler(this.Uchet_Furnitury_Load);
            this.Panel.ResumeLayout(false);
            this.Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logotip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mebelnaya_FabrikaDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.furnituraBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.furnituraDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel Panel;
        private System.Windows.Forms.Label Metka_Uchet_Furnitury;
        private System.Windows.Forms.PictureBox Logotip;
        private Mebelnaya_FabrikaDataSet mebelnaya_FabrikaDataSet;
        private System.Windows.Forms.BindingSource furnituraBindingSource;
        private Mebelnaya_FabrikaDataSetTableAdapters.FurnituraTableAdapter furnituraTableAdapter;
        private Mebelnaya_FabrikaDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView furnituraDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.Button Nazad;
        private System.Windows.Forms.Button Otmena;
        private System.Windows.Forms.Label Metka_Tip;
        private System.Windows.Forms.Button Nayti;
        private System.Windows.Forms.TextBox tbPoisk;
        private System.Windows.Forms.Button Sohranit;
        private System.Windows.Forms.Button Udalit;
    }
}